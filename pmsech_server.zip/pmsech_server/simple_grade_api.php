<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// کلید API
$valid_api_key = 'pmsech_grade_api_2024';

// تابع احراز هویت ساده
function authenticate() {
    global $valid_api_key;
    
    $api_key = isset($_GET['api_key']) ? $_GET['api_key'] : '';
    
    if ($api_key !== $valid_api_key) {
        http_response_code(401);
        echo json_encode([
            'success' => false,
            'error' => 'احراز هویت ناموفق',
            'message' => 'کلید API نامعتبر است'
        ]);
        exit;
    }
    
    return true;
}

// دریافت درخواست
$action = $_GET['action'] ?? '';

// احراز هویت
authenticate();

// پردازش درخواست
switch ($action) {
    case 'download':
        downloadGrades();
        break;
    case 'stats':
        getStats();
        break;
    case 'upload':
        uploadGrade();
        break;
    default:
        echo json_encode([
            'success' => false,
            'error' => 'عملیات نامعتبر',
            'message' => 'عملیات مشخص نشده است'
        ]);
        break;
}

// تابع دانلود داده‌های نمونه
function downloadGrades() {
    $sample_data = [
        // 1403/10/1
        [
            'date' => '1403/10/1',
            'grade_type' => 'خوراک',
            'grade_value' => 28.52
        ],
        [
            'date' => '1403/10/1',
            'grade_type' => 'محصول',
            'grade_value' => 38.12
        ],
        [
            'date' => '1403/10/1',
            'grade_type' => 'باطله',
            'grade_value' => 9.63
        ],
        // 1403/10/2
        [
            'date' => '1403/10/2',
            'grade_type' => 'خوراک',
            'grade_value' => 22.19
        ],
        [
            'date' => '1403/10/2',
            'grade_type' => 'محصول',
            'grade_value' => 34.82
        ],
        [
            'date' => '1403/10/2',
            'grade_type' => 'باطله',
            'grade_value' => 8.74
        ],
        // 1403/10/3
        [
            'date' => '1403/10/3',
            'grade_type' => 'خوراک',
            'grade_value' => 28.56
        ],
        [
            'date' => '1403/10/3',
            'grade_type' => 'محصول',
            'grade_value' => 42.17
        ],
        [
            'date' => '1403/10/3',
            'grade_type' => 'باطله',
            'grade_value' => 9.32
        ],
        // 1403/10/4
        [
            'date' => '1403/10/4',
            'grade_type' => 'خوراک',
            'grade_value' => 31.65
        ],
        [
            'date' => '1403/10/4',
            'grade_type' => 'محصول',
            'grade_value' => 37.58
        ],
        [
            'date' => '1403/10/4',
            'grade_type' => 'باطله',
            'grade_value' => 8.82
        ],
        // 1403/10/5
        [
            'date' => '1403/10/5',
            'grade_type' => 'خوراک',
            'grade_value' => 34.41
        ],
        [
            'date' => '1403/10/5',
            'grade_type' => 'محصول',
            'grade_value' => 42.34
        ],
        [
            'date' => '1403/10/5',
            'grade_type' => 'باطله',
            'grade_value' => 9.56
        ],
        // 1404/4/1
        [
            'date' => '1404/4/1',
            'grade_type' => 'خوراک',
            'grade_value' => 30.0
        ],
        [
            'date' => '1404/4/1',
            'grade_type' => 'محصول',
            'grade_value' => 40.0
        ],
        [
            'date' => '1404/4/1',
            'grade_type' => 'باطله',
            'grade_value' => 10.0
        ],
        // 1404/4/2
        [
            'date' => '1404/4/2',
            'grade_type' => 'خوراک',
            'grade_value' => 32.5
        ],
        [
            'date' => '1404/4/2',
            'grade_type' => 'محصول',
            'grade_value' => 41.2
        ],
        [
            'date' => '1404/4/2',
            'grade_type' => 'باطله',
            'grade_value' => 11.8
        ]
    ];
    
    echo json_encode([
        'success' => true,
        'data' => $sample_data,
        'count' => count($sample_data),
        'message' => 'داده‌های نمونه با موفقیت دریافت شد'
    ]);
}

// تابع دریافت آمار
function getStats() {
    $stats = [
        'total_records' => 6,
        'by_type' => [
            'خوراک' => 2,
            'محصول' => 2,
            'باطله' => 2
        ],
        'by_date' => [
            '1403/10/1' => 3,
            '1403/10/2' => 3
        ]
    ];
    
    echo json_encode([
        'success' => true,
        'stats' => $stats,
        'message' => 'آمار با موفقیت دریافت شد'
    ]);
}

// تابع آپلود (ساده)
function uploadGrade() {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode([
            'success' => false,
            'error' => 'داده نامعتبر',
            'message' => 'داده JSON نامعتبر است'
        ]);
        return;
    }
    
    // بررسی فیلدهای الزامی
    $required_fields = ['date', 'grade_type', 'grade_value'];
    foreach ($required_fields as $field) {
        if (!isset($input[$field])) {
            echo json_encode([
                'success' => false,
                'error' => 'فیلد الزامی',
                'message' => "فیلد $field الزامی است"
            ]);
            return;
        }
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'عیار با موفقیت ثبت شد (نمونه)',
        'data' => $input
    ]);
}
?> 